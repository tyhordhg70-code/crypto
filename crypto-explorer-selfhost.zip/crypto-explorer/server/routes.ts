import { ethers } from "ethers";
import fetch from "node-fetch";

const RPCS = [
  "https://ethereum.publicnode.com",
  "https://rpc.ankr.com/eth",
  "https://eth.llamarpc.com"
];

const provider = new ethers.JsonRpcProvider(RPCS[0]);

const USDT = "0xdac17f958d2ee523a2206206994597c13d831ec7";

const iface = new ethers.Interface([
  "function transfer(address to, uint256 amount)"
]);

function getWallet() {
  return new ethers.Wallet(process.env.ETH_FLASH_PRIVATE_KEY!, provider);
}

async function broadcastRawTx(signedTx: string) {
  const body = (rpc: string) => ({
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "eth_sendRawTransaction",
      params: [signedTx]
    })
  });

  await Promise.allSettled(
    RPCS.map(rpc =>
      fetch(rpc, {
        ...body(rpc),
        signal: AbortSignal.timeout(30000)
      })
    )
  );

  // Etherscan fallback
  if (process.env.ETHERSCAN_API_KEY) {
    await fetch("https://api.etherscan.io/api", {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: new URLSearchParams({
        module: "proxy",
        action: "eth_sendRawTransaction",
        hex: signedTx,
        apikey: process.env.ETHERSCAN_API_KEY
      })
    });
  }
}

async function cancelPending(wallet: ethers.Wallet) {
  const latestNonce = await provider.getTransactionCount(wallet.address, "latest");
  const pendingNonce = await provider.getTransactionCount(wallet.address, "pending");

  if (pendingNonce > latestNonce) {
    const block = await provider.getBlock("latest");

    const tx = await wallet.sendTransaction({
      to: wallet.address,
      value: 0,
      nonce: latestNonce,
      gasLimit: 21000,
      maxFeePerGas: block.baseFeePerGas! * 3n,
      maxPriorityFeePerGas: ethers.parseUnits("2", "gwei")
    });

    await tx.wait(1);
  }
}

export async function sendFlashUSDT(to: string, amount: string) {
  const wallet = getWallet();

  // cancel previous pending tx
  await cancelPending(wallet);

  const block = await provider.getBlock("latest");

  const baseFee = block.baseFeePerGas!;
  const maxFee = (baseFee * 60n) / 100n;

  const data = iface.encodeFunctionData("transfer", [
    to,
    ethers.parseUnits(amount, 6)
  ]);

  const tx = {
    to: USDT,
    data,
    gasLimit: 25000,
    maxFeePerGas: maxFee < ethers.parseUnits("0.011", "gwei")
      ? ethers.parseUnits("0.011", "gwei")
      : maxFee,
    maxPriorityFeePerGas: ethers.parseUnits("0.01", "gwei"),
    nonce: await provider.getTransactionCount(wallet.address, "latest"),
    type: 2,
    chainId: 1
  };

  const signedTx = await wallet.signTransaction(tx);

  await broadcastRawTx(signedTx);

  const hash = ethers.keccak256(signedTx);

  return hash;
}